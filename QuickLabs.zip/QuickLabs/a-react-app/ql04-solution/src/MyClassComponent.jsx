import React, { Component } from 'react';

class MyClassComponent extends Component {

    render() {
        return (
            <>
                <h2>Class Components</h2>
                <p>Work in a similar way to Function Components</p>
            </>
        );
    }
}

export default MyClassComponent;

